import { Component, OnInit } from '@angular/core';
import { NewsArticlesService } from '../../service/news-articles.service';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.scss'],
})
export class TechnologyComponent implements OnInit {
  techDisplay: any = [];
  totalLength: any;
  page: number = 1;

  constructor(private _service: NewsArticlesService) {}

  ngOnInit(): void {
    this._service.techNews().subscribe((result) => {
      this.techDisplay = result.data;

      this.totalLength = result.length;
    });
  }
}
