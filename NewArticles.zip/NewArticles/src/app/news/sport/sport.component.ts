import { Component, OnInit } from '@angular/core';
import { NewsArticlesService } from '../../service/news-articles.service';

@Component({
  selector: 'app-sport',
  templateUrl: './sport.component.html',
  styleUrls: ['./sport.component.scss'],
})
export class SportComponent implements OnInit {
  sportDisplay: any = [];
  totalLength: any;
  page: number = 1;

  constructor(private _service: NewsArticlesService) {}

  ngOnInit(): void {
    this._service.sportNews().subscribe((result) => {
      this.sportDisplay = result.data;

      this.totalLength = result.length;
    });
  }
}
