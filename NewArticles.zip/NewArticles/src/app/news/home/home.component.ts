import { Component, OnInit } from '@angular/core';
import { NewsArticlesService } from '../../service/news-articles.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  homeDisplay: any = [];
  totalLength: any;
  page: number = 1;

  constructor(private _service: NewsArticlesService) {}

  ngOnInit(): void {
    this._service.home().subscribe((result) => {
      this.homeDisplay = result.data;
      console.log(result);

      this.totalLength = result.length;
    });
  }
}
