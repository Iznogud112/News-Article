import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './news/home/home.component';
import { SportComponent } from './news/sport/sport.component';
import { TechnologyComponent } from './news/technology/technology.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'sport', component: SportComponent },
  { path: 'tech', component: TechnologyComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
