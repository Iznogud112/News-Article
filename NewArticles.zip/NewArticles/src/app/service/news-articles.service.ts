import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

const newsApiUrl =
  'http://api.mediastack.com/v1/news?access_key=6363cfb2491a35163b487eabd33067f1&languages=en';
const techApiUrl =
  'http://api.mediastack.com/v1/news?access_key=6363cfb2491a35163b487eabd33067f1&languages=en&categories=technology';
const sportApiUrl =
  'http://api.mediastack.com/v1/news?access_key=6363cfb2491a35163b487eabd33067f1&languages=en&categories=sports';

@Injectable({
  providedIn: 'root',
})
export class NewsArticlesService {
  constructor(private _http: HttpClient) {}

  home(): Observable<any> {
    return this._http.get(newsApiUrl);
  }

  sportNews(): Observable<any> {
    return this._http.get(sportApiUrl);
  }

  techNews(): Observable<any> {
    return this._http.get(techApiUrl);
  }

  /*
  searchNews() {
    return this._http.get(newsApiUrl, {
      params: {
        access_key: 'ACCESS_KEY',
        categories: ',-sports',
        limit: '10',
      },
    });
  }

  sort() {
    return this._http.get(`${newsApiUrl}&published_desc`);
  }
  */
}
