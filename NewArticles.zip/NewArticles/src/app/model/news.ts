export interface News {
  id: number;
  title: string;
  description: string;
  author: string;
  date: Date;
  imageUrl: string;
}
