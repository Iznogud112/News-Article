import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { NgxPaginationModule } from 'ngx-pagination';

import { AppComponent } from './app.component';
import { NewsArticlesService } from './service/news-articles.service';
import { NavbarComponent } from './core/navbar/navbar.component';
import { FooterComponent } from './core/footer/footer.component';
import { HomeComponent } from './news/home/home.component';
import { SportComponent } from './news/sport/sport.component';
import { TechnologyComponent } from './news/technology/technology.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SportComponent,
    TechnologyComponent,
    NavbarComponent,
    FooterComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    LoadingBarHttpClientModule,
    NgxPaginationModule,
  ],

  providers: [NewsArticlesService],
  bootstrap: [AppComponent],
})
export class AppModule {}
